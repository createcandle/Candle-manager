<?php phpinfo ();?>
