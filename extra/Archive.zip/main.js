$(document).ready(function(){
	console.log("hi!");
	
	// REGISTERING SOME BUTTONS
	
	$('.menuitem').click(function(){
		$('.togglerow').hide().eq($(this).index()-1).show();
		$('#editRow, #uploadWizard').hide();
		//$('#source-list').show();
	});
	
	$('#saveCode').click(function(){
		codeName = $('#editing-h1').text();
		console.log("Saving: " + codeName);
		saveCode(codeName);
	});
	
	$('#saveAndUpload').click(function(){
		codeName = $('#editing-h1').text();
		console.log("saving and moving to upload wizard for: "  + codeName);
		saveCode(codeName);
		console.log("will try to move to upload wizard for: ");
		$("#three, #editRow").hide();
		resetUploadWizard();
		$('#uploadWizard').show();
		$( "#uploadWizard" ).data('name', codeName );
		$( "#uploadheaderName" ).text(codeName.replace(/\_/g, ' '));
	});	
	
	
	$('#firstScanButton').click(function(){
		console.log("Doing a first scan of connected Arduino's");
		firstScan();
		$('#firstScanButton').hide();
		$('#firstScanning').show();
	});
	
	$('#rescanButton').click(function(){
		console.log("Doing a new scan of connected Arduino's");
		rescan();
		$('#rescanButton').hide();
		$('#rescanning').show();
	});

	$('#backScanButton').click(function(){
		console.log("Wizard is going back to beginning.");
		$('#rescanButton').hide();
		$('#rescanning').show();
		$('#firstScanButton').show();
	});

	updateCodeList();
	updateSourceList();
	
	$("#addNewCode").submit(function(event){
		console.log("User is submitting for to create code for a new device (step 1)");
		
		// stop form from submitting normally.
		event.preventDefault();
		event.stopPropagation();
		
		// we need to names: of the source file and of the new file name that is provided in the form.
		sourceName = $("#newSettings").data('sourceName');
		console.log("1. Getting input variables for source: " + sourceName);
		
		codeName = $("#newName").val().replace(/\W\s/g, '');
		
		if(codeName.length > 0){
		
			console.log("new code name: " + codeName);
			
			//location.href = "#newSettings";
			
			// Get values from inputs.
			returnValues = [];
			$('#nameGroupHolder :input').each(function(index){
				//console.log("ITEM");
				//console.log( $(this).val() );
				returnValue = $(this).val();
				if(returnValue == "checkbox"){
					if($(this).is(":checked")){
						returnValue = 1;
					}else{
						returnValue = 0;
					}
				}
				returnValues.push(returnValue);
			});
			//console.log(returnValues);

			// send the preferences to the PHP file that will generate a new ino file from it.
			$.ajax({
				type: "POST",
				url: "manage.php",
				//data: JSON.stringify(allTheVariables),
				data: {sourceName:sourceName,codeName:codeName,returnValues:returnValues},
				//data: { code: code, name : fileName },
				dataType: "JSON",
				success: function(json){
					console.log(json);
					if(json[0] == "OK"){
						console.log("Save success");
						updateCodeList();
						alert("New code created succesfully.")
						// We can now show part 2 - the upload wizard.
						console.log("will try to move to upload wizard for: " + codeName);
						$("#three, #newSettings").hide();
						resetUploadWizard();
						$('#uploadWizard').show();
						$( "#uploadWizard" ).data('name', codeName );
						$( "#uploadheaderName" ).text(codeName.replace(/\_/g, ' '));
					}else{
						alert(json);
					}
				}
			});
		}else{
			alert("Please make the name longer and/or use only letters from the alphabet.");
		}
		
		return false;
	});	
	
});


	function resetUploadWizard(){		
		$("#disconnect, #firstScanButton, #rescanButton").show();
		$("#plugitin, #currentlyUploading, #firstScanning, #rescanning, #foundDevicesHolder").hide();
		$( "#uploadheaderName" ).text("");
	}


	function updateCodeList(){
		// get created code
		console.log("getting generated code list");
		$.ajax({
			//url: "yourphp.php?id="+yourid,
			url: "./manage.php?list=code",
			dataType: "JSON",
			success: function(json){
				//here inside json variable you've the json returned by your PHP
				html = '<table class="table table-bordered table-striped" id="codelist-table">';
				for(var i=0;i<json.length;i++){
					html += '<tr><td><h4>' + json[i].replace(/\_/g, ' ') + '</h4></td>';
					html += '<td><a class="remove btn" onclick="removeCode(\'' + json[i] + '\');"><button class="btn btn-danger">REMOVE</button></a></td>';
					html += '<td><a class="edit btn" onclick="editCode(\'' + json[i] + '\');"><button class="btn btn-primary">EDIT</button></a></td>';
					html += '<td><a class="upload btn" onclick="uploadCode(\'' + json[i] + '\');"><button class="btn btn-info">UPLOAD</button></a></td></tr>';
				}
				html += '</table>';
				$('#codelist').html(html);
			}
		});
	}
	
	function updateSourceList(){
		console.log("getting source list");
		// get available source files
		$.ajax({
			url: "./manage.php?list=source",
			dataType: "JSON",
			success: function(json){
				
				for(var i=0;i<json.length;i++){
					console.log(json[i]);
					$( "#the-original" ).clone().attr('id', '').appendTo( "#source-list" );
					$( "#source-list > div:last-child .panel-primary" ).string_to_color(["border-color"], json[i]);
					$( "#source-list > div:last-child .panel-heading" ).string_to_color(["background", "border-color"], json[i]);
					$( "#source-list > div:last-child a" ).data('name', json[i]);
					$( "#source-list > div:last-child .panel-heading h2").text(json[i].replace(/\_/g, ' ') );
					$( "#source-list > div:last-child").show();
				}
				
				// CREATE NEW DEVICE FROM NEW SETTINGS
				
				$( "#source-list a").click(function(){
					console.log("Clicked create new");
					sourceName = $(this).data('name');
					$('#newName').val(sourceName.replace(/\_/g, ' ') );
					
					getVariables(sourceName);
					$("#newSettings").show();
					
					sourcePath = 'source/' + sourceName + '/' + sourceName + '.ino';
					console.log(sourcePath);

					$.get(sourcePath, function(response) {
						console.log("Loading the new about text");
						

						var aboutText = response.slice(0, response.indexOf("* SETTINGS */"));
						//aboutText.replace(/\n/g,"<br/>");
						//aboutText = aboutText.replace(~[\*]~, '<br>');
						aboutText = aboutText.replace(/^\//, '');
						aboutText = aboutText.replace(/\*/g, '<br/>');
						//aboutText = aboutText.replace(/(?:\r\n|\r|\n)/g, '<br/>');
						console.log(aboutText);
						$('#aboutNewDevice').html(aboutText);
					});
					
					
				});
			}
		});
	}
	
	

	function getVariables(sourceName){
		console.log("getting variables for" + sourceName);
		
		$('#newDeviceSourceName').text(sourceName.replace(/\_/g, ' ') );
		$( "#newSettings" ).data('sourceName', sourceName);
		
		$.ajax({
			url: "./manage.php?variables=" + sourceName,
			dataType: "JSON",
			success: function(json){
				$("#nameGroupHolder").html('');
				for(var i=0;i<json.length;i++){
					console.log(json[i]);
					
					html = '<hr/><div class="form-group"><label>';
					
					if ('checkbox' in json[i]){
						checkedStatus = "";
						if(json[i].checkbox){
							checkedStatus = "checked";
						}
						html += '<input type="checkbox" value="checkbox" ' + checkedStatus + '>' + json[i].comment + '</label>';
					}
					if ('input' in json[i]){
						html += json[i].comment + '</label>';
						html += '<input class="form-control " value="' + json[i].input + '">';
					}
					html += '</div>'
					$("#nameGroupHolder").append(html);
				}
			}
		});
	}


	function removeCode(fileName){
		//console.log("adding remove detection");
		console.log("clicked remove button");
		var checkstr =  confirm('Are you sure you want to delete this?');
		if(checkstr == true){
			$.get("manage.php?toDelete=" + fileName, function(json) {
				console.log(json);
				if(json[0] == "OK"){
					updateCodeList();
				}else{
					alert(json);
				}
			});
		}
	}

	function uploadCode(codeName){
		console.log("User wants to upload" + codeName);
		$('.togglerow').hide();
		resetUploadWizard();
		$('#uploadWizard').show();
		$( "#uploadWizard" ).data('name', codeName );
		$( "#uploadheaderName" ).text(codeName.replace(/\_/g, ' '));
	}

	function editCode(codeName){
		console.log("Editing");
		console.log(codeName);
		
		$('.togglerow').hide();
		$('#editRow').show();
		$('#editing-h1').text(codeName.replace(/\_/g, ' '));
		
		codePath = 'code/' + codeName + '/' + codeName + '.ino';
		console.log(codePath);
		
		$.get(codePath, function(response) {
			console.log("got response");
			console.log(response);
			cEditor.setValue(response);
			cEditor.clearHistory();
		});
	}


	function saveCode(fileName){
		console.log("Save code name: " + fileName);
		code = encodeURIComponent( cEditor.getValue() );
		console.log("new code: " + code);

		$.ajax({
			type: "POST",
			url: "manage.php",
			data: { code: code, name : fileName },
			dataType: "JSON",
			success: function(json){
				if(json[0] == "OK"){
					alert("The code has been saved.");
				}else{
					alert(json);
				}
			}
		});
	}	

	
	// do the initial scan of connected devices.
	function firstScan(){
		$.ajax({
			url: "./manage.php?cli=firstScan",
			dataType: "JSON",
			success: function(json){
				if(json[0] == "OK"){
					$('#disconnect').hide();
					$('#plugitin').show();
				}else{
					alert(json);
				}
			}
		});
	}
	
	
	function rescan(){
		$( "#foundDevicesHolder .panel-body").html('');
		$.ajax({
			url: "./manage.php?cli=rescan",
			dataType: "JSON",
			success: function(json){
				console.log(json);
				
				//var data = $.parseJSON(json);
				$(json).each(function(i,val){
					
					$( "#the-original-arduino" ).clone().attr('id', '').appendTo( "#foundDevicesHolder .panel-body" );
					$( "#foundDevicesHolder .panel-body > div:last-child .panel-primary" ).string_to_color(["border-color"], val["productID"] );
					$( "#foundDevicesHolder .panel-body > div:last-child .panel-heading" ).string_to_color(["background", "border-color"], val["productID"] );
					$( "#foundDevicesHolder .panel-body > div:last-child a" ).data('port', val["port"] );
					$( "#foundDevicesHolder .panel-body > div:last-child a" ).data('name', val["name"] );
					$( "#foundDevicesHolder .panel-body > div:last-child .port" ).text( val["port"] );
					displayName = val["name"];
					if(displayName == "unknown"){displayName = "Arduino";}
					$( "#foundDevicesHolder .panel-body > div:last-child .panel-heading h3").text( displayName ); //.replace(/\_/g, ' ') 
					$( "#foundDevicesHolder .panel-body > div:last-child").show();

					
					
					// THE CLICK FUNCTION FOR EACH FOUND ARDUINO
					$( "#foundDevicesHolder .panel-body > div:last-child a").click(function(){
						console.log("Clicked on an arduino to upload to.");
						uploadPort = $(this).data('port');
						uploadName = $( "#uploadWizard" ).data('name');
						console.log(uploadName);
						console.log(uploadPort);
						//$("#plugitin").hide();
						$("#uploadDebugOutput").val('');
						$("#currentlyUploading").show();
						getDebugOutput(); // Start periodically checking for debug output from the upload command.

						path = "manage.php?cli=upload&name=" + uploadName + "&port=" + uploadPort;
						$.get(path, function(json) {
							console.log(json);
						});
					});
				});
				
				$('#rescanButton').text("Rescan").show();
				$('#rescanning').hide();
				$('#foundDevicesHolder').show();
				
			}
		});
	}
	


	// runs every second to show data from the upload proces output file.
	function getDebugOutput()
	{
		shouldContinue = true;
		$.ajax({
			url : "uploadoutput.txt",
			dataType: "text",
			success : function (data) {
				if( $("#uploadDebugOutput").val() != data){
					$("#uploadDebugOutput").val(data);
					var textarea = document.getElementById('uploadDebugOutput');
					textarea.scrollTop = textarea.scrollHeight;
					
					if (data.indexOf("Compilation failed") >= 0){
						alert("Upload failed - Error in the code!");
						shouldContinue = false;
					}else if (data.indexOf("flash verified") > 0){
						alert("Uploading has completed succesfully");
						shouldContinue = false;
					}
					
					
				}
			}
		});

		if( $('#uploadWizard').is(":visible") && shouldContinue == true ){
			setTimeout(getDebugOutput, 1000);
		}
	}







/*!
 * jquery-string_to_color
 * A jQuery plugin based on string_to_color by Brandon Corbin.
 *
 * Source:
 * https://github.com/erming/jquery-string_to_color
 *
 * Version 0.1.0
 */
(function($) {
	/**
	 * Generate hex color code from a string.
	 *
	 * @param {String} str
	 */
	$.string_to_color = function(str) {
		return "#" + string_to_color(str);
	};
	
	/**
	 * Set one or more CSS properties for the set of matched elements.
	 *
	 * @param {String|Array} property
	 * @param {String} str
	 */
	$.fn.string_to_color = function(property, string) {
		if (!property || !string) {
			throw new Error("$(selector).string_to_color() takes 2 arguments");
		}
		return this.each(function() {
			var props = [].concat(property);
			var $this = $(this);
			$.map(props, function(p) {
				$this.css(p, $.string_to_color(string));
			});
		});
	};
})(jQuery);
 
/********************************************************
Name: str_to_color
Description: create a hash from a string then generates a color
Usage: alert('#'+str_to_color("Any string can be converted"));
author: Brandon Corbin [code@icorbin.com]
website: http://icorbin.com
********************************************************/

function string_to_color(str, options) {

    // Generate a Hash for the String
    this.hash = function(word) {
        var h = 0;
        for (var i = 0; i < word.length; i++) {
            h = word.charCodeAt(i) + ((h << 5) - h);
        }
        return h;
    };

    // Change the darkness or lightness
    this.shade = function(color, prc) {
        var num = parseInt(color, 16),
            amt = Math.round(2.55 * prc),
            R = (num >> 16) + amt,
            G = (num >> 8 & 0x00FF) + amt,
            B = (num & 0x0000FF) + amt;
        return (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
            (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
            (B < 255 ? B < 1 ? 0 : B : 255))
            .toString(16)
            .slice(1);

    };
    
    // Convert init to an RGBA
    this.int_to_rgba = function(i) {
        var color = ((i >> 24) & 0xFF).toString(16) +
            ((i >> 16) & 0xFF).toString(16) +
            ((i >> 8) & 0xFF).toString(16) +
            (i & 0xFF).toString(16);
        return color;
    };

    return this.shade(this.int_to_rgba(this.hash(str)), -10);

}
